# Chicken Salad Chick Nutrition – Next.js Website

## Installation

1. Extract the ZIP file
2. Run:

npm install
npm run dev

3. Open http://localhost:3000

This project is built using Next.js 14 (App Router).
